/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import org.junit.Test;
import static org.junit.Assert.*;


public class PersonTest {

   @Test
public void testPersonConstructor() {
    // Código de la prueba
}
    @Test
    public void testCalculateBMI() {
        Person person1 = new Person("Person1", 30, 'M', 80, 1.8);
        assertEquals(0, person1.calculateBMI());

        Person person2 = new Person("Person2", 25, 'F', 50, 1.65);
        assertEquals(-1, person2.calculateBMI());

        Person person3 = new Person("Person3", 40, 'M', 90, 1.7);
        assertEquals(1, person3.calculateBMI());
    }

    @Test
    public void testIsAdult() {
        Person adult = new Person("Adult", 25, 'F', 60, 1.6);
        assertTrue(adult.isAdult());

        Person minor = new Person("Minor", 16, 'M', 45, 1.55);
        assertFalse(minor.isAdult());
    }
}