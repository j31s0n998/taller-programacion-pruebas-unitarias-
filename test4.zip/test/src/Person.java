import java.util.Random;
public class Person {
    private static final char DEFAULT_GENDER = 'M';
    private static final int MIN_AGE_TO_BE_ADULT = 18;

    private String name;
    private int age;
    private String id;
    private char gender;
    private double weight;
    private double height;

    public Person() {
        this("", 0, DEFAULT_GENDER);
    }

    public Person(String name, int age, char gender) {
        this(name, age, gender, 0, 0);
    }

    public Person(String name, int age, char gender, double weight, double height) {
        this.name = name;
        this.age = age;
        this.gender = validateGender(gender);
        this.weight = weight;
        this.height = height;
        this.id = generateId();
    }

    public int calculateBMI() {
        double bmi = weight / (height * height);
        if (bmi < 20) {
            return -1;
        } else if (bmi <= 25) {
            return 0;
        } else {
            return 1;
        }
    }

    public boolean isAdult() {
        return age >= MIN_AGE_TO_BE_ADULT;
    }

    private char validateGender(char gender) {
        if (gender == 'M' || gender == 'F') {
            return gender;
        } else {
            return DEFAULT_GENDER;
        }
    }

    public String toString() {
        return "Name: " + name + "\n" +
               "Age: " + age + "\n" +
               "ID: " + id + "\n" +
               "Gender: " + gender + "\n" +
               "Weight: " + weight + "\n" +
               "Height: " + height;
    }

    private String generateId() {
        Random random = new Random();
        StringBuilder idBuilder = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            idBuilder.append(random.nextInt(10));
        }
        return idBuilder.toString();
    }

    // Getters and setters for attributes
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = validateGender(gender);
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }
}